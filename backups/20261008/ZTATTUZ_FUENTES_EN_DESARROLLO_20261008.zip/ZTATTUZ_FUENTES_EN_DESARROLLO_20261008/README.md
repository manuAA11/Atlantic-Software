# ZTATTUZ: respaldo de fuentes en desarrollo

Contiene todas las fuentes recuperadas disponibles de este producto, assets, pruebas, migraciones y configuración publicable.
No es una entrega final ni un instalador. Falta el redistribuible DigitalPersona autorizado y la aceptación externa/Windows.
No hay secretos, venv ni node_modules; instalar requirements.txt y npm ci en cada edición.
CPython 3.13 y 3.14 estándar: 64 bits Comercial/ZTATTUZ x64; 32 bits ZTATTUZ x86.
Para abrir desde fuentes: INICIAR_ADMINISTRADOR.bat o INICIAR_RECEPCION.bat. No hace falta generar un instalador para configurar/probar.
Leer docs/ESTADO_CIERRE.md y docs/INTEGRACIONES_Y_WINDOWS.md. Conservar release_readiness.json: no forzar los criterios a true.

Ediciones incluidas: GymSoft_ZTATTUZ_3.6.1_x64, GymSoft_ZTATTUZ_3.6.1_x86.
Entradas: app.py (Administrador), reception_app.py (Recepción); owner_panel.py solo en Comercial y privado del propietario.
Los generadores comunes que sincronizan productos esperan el monorepo completo. El runtime y build de cada edición son independientes.
