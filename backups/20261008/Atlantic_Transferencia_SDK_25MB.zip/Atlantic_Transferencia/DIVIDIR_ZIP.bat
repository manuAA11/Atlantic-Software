@echo off
setlocal
cd /d "%~dp0"
py partir_archivo.py
if errorlevel 1 echo Revisa el mensaje anterior. Tus ZIP originales se conservan.
pause
